<?php
 
App::uses('Component', 'Controller');
 
class BasicComponent extends Component {
 
    public function getBedRates($hotel_id, $room_id, $bed_type_id) { 
        return '2222';

    }
}

?>