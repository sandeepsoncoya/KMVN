<?php
App::uses('AppModel', 'Model');
/**
* RoomReservation Model
*
*/
class RoomReservation extends AppModel {

public $name = 'RoomReservation';
public $useTable = 'room_reservation';


}
